# Project Name
Solutions for the dataset used in the Kaggle Competition: Binary Classification of Insurance Cross Selling

Competition URL: https://www.kaggle.com/competitions/playground-series-s4e7/data

# Content
## Results
- Softmax - 67.5

# Roadmap
- [ ] Checklist item